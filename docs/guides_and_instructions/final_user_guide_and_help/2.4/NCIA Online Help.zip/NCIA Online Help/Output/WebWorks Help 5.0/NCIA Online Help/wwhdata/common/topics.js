function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="user_registration_help")C="Getting%20Started.2.3.html#1084793";
if(P=="welcome_login_help")C="Getting%20Started.2.4.html#1084015";
if(P=="welcome_post_login_help")C="Getting%20Started.2.5.html#1102085";
if(P=="news_page_help")C="Getting%20Started.2.10.html#1091593";
if(P=="online_help_help")C="Getting%20Started.2.14.html#1130484";
if(P=="remote_site_help")C="Searching%20NCIA.3.2.html#1123307";
if(P=="simple_search_help")C="Searching%20NCIA.3.4.html#1113864";
if(P=="criteria_selected_help")C="Searching%20NCIA.3.5.html#1186206";
if(P=="annotation_keyword_search_help")C="Searching%20NCIA.3.7.html#1102496";
if(P=="advanced_search_help")C="Searching%20NCIA.3.8.html#1066935";
if(P=="saved_queries_help")C="Searching%20NCIA.3.11.html#1066885";
if(P=="save_edited_query_help")C="Searching%20NCIA.3.12.html#1068625";
if(P=="query_history_help")C="Searching%20NCIA.3.13.html#1092117";
if(P=="search_results_by_subject_help")C="Searching%20NCIA.3.15.html#1085991";
if(P=="search_results_studies_for_subject_help")C="Searching%20NCIA.3.16.html#1069240";
if(P=="search_results_images_for_series_help")C="Searching%20NCIA.3.17.html#1069282";
if(P=="data_basket_help")C="Searching%20NCIA.3.20.html#1070197";
if(P=="QA_tool_help")C="NCIA%20admin.4.3.html#1084993";
if(P=="upload_spreadsheet_help")C="NCIA%20admin.4.5.html#1083943";
if(P=="verify_submitted_files_help")C="NCIA%20admin.4.6.html#1084915";
return C;
}
