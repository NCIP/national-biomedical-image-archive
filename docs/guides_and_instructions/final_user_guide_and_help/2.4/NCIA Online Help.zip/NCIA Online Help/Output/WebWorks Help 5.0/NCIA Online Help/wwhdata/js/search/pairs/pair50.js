function FileData_Pairs(x)
{
x.t("access","http://imaging.nci.nih.gov");
x.t("url","references");
x.t("references","ncia");
x.t("portal","site");
x.t("ncia","access");
x.t("ncia","url");
x.t("ncia","portal");
x.t("ncia","ncia");
x.t("site","http://ncia.nci.nih.gov");
x.t("http://imaging.nci.nih.gov","ncia");
}
