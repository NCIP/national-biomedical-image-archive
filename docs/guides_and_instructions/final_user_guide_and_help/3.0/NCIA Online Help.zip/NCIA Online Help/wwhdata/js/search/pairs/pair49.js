function FileData_Pairs(x)
{
x.t("dicomworks","dicom");
x.t("http://medical.nema.org/","imagej");
x.t("imagej","dicom");
x.t("osirix","dicom");
x.t("url","references");
x.t("references","dicom");
x.t("http://homepage.mac.com/rossetantoine/osirix/","dicomworks");
x.t("viewer","http://homepage.mac.com/rossetantoine/osirix/");
x.t("viewer","http://rsb.info.nih.gov/ij/");
x.t("viewer","http://www.dicomworks.com/");
x.t("http://rsb.info.nih.gov/ij/","osirix");
x.t("dicom","http://medical.nema.org/");
x.t("dicom","url");
x.t("dicom","viewer");
x.t("dicom","dicom");
}
