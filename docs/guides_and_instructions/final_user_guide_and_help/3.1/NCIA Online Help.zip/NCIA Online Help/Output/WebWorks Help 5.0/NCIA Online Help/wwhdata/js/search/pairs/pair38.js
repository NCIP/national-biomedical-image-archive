function FileData_Pairs(x)
{
x.t("searching","ncia");
x.t("initiating","searches");
x.t("searches","ncia");
x.t("searches","applications");
x.t("accessing","ncia");
x.t("launched","applications");
x.t("archives","initiating");
x.t("ncia","launched");
x.t("ncia","archives");
x.t("ncia","application");
x.t("information","accessing");
x.t("applications","searching");
x.t("applications","initiating");
x.t("applications","searches");
x.t("applications","information");
}
