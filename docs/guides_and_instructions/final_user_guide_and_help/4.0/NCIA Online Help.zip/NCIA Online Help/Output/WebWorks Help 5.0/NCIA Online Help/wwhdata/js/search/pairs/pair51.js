function FileData_Pairs(x)
{
x.t("lists","urls");
x.t("url","references");
x.t("products","dicom");
x.t("references","url");
x.t("references","section");
x.t("cedara","ncia");
x.t("software","products");
x.t("section","lists");
x.t("client","software");
x.t("ftp","client");
x.t("dicom","cedara");
x.t("ncia","ftp");
x.t("urls","associated");
x.t("associated","ncia");
}
