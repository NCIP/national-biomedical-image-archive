function FileData_Pairs(x)
{
x.t("searching","images");
x.t("initiating","searches");
x.t("images","initiating");
x.t("searches","ncia");
x.t("searches","applications");
x.t("accessing","ncia");
x.t("launched","applications");
x.t("ncia","launched");
x.t("ncia","application");
x.t("information","accessing");
x.t("applications","searching");
x.t("applications","initiating");
x.t("applications","searches");
x.t("applications","information");
}
