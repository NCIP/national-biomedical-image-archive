// Copyright (c) 2000-2003 Quadralay Corporation.  All rights reserved.
//

// Load book search info
//
WWHFrame.WWHSearch.fInitLoadBookSearchInfo(WWHBookData_SearchFileCount(),
                                           WWHBookData_SearchMinimumWordLength(),
                                           WWHBookData_SearchSkipWords);
