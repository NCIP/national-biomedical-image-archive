function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="user_registration_help")C="Getting%20Started.2.3.html#1084793";
if(P=="welcome_login_help")C="Getting%20Started.2.5.html#1149786";
if(P=="change_password_help")C="Getting%20Started.2.6.html#1109695";
if(P=="welcome_post_login_help")C="Getting%20Started.2.7.html#1155561";
if(P=="news_page_help")C="Getting%20Started.2.12.html#1091593";
if(P=="online_help_help")C="Getting%20Started.2.17.html#1158282";
if(P=="simple_search_help")C="Searching%20NBIA.3.3.html#1066741";
if(P=="advanced_search_help")C="Searching%20NBIA.3.4.html#1207980";
if(P=="dynamic_search_help")C="Searching%20NBIA.3.5.html#1208463";
if(P=="dynamic_search,_configuring")C="Searching%20NBIA.3.5.html#1208471";
if(P=="criteria_selected_help")C="Searching%20NBIA.3.6.html#1212337";
if(P=="annotation_keyword_search_help")C="Searching%20NBIA.3.7.html#1095060";
if(P=="remote_site_help")C="Searching%20NBIA.3.9.html#1205557";
if(P=="saved_queries_help")C="Searching%20NBIA.3.12.html#1066885";
if(P=="save_edited_query_help")C="Searching%20NBIA.3.13.html#1153808";
if(P=="query_history_help")C="Searching%20NBIA.3.14.html#1092117";
if(P=="search_results_by_subject_help")C="Viewing%20Search%20Results.4.3.html#1085991";
if(P=="search_results_studies_for_subject_help")C="Viewing%20Search%20Results.4.4.html#1069240";
if(P=="search_results_images_for_series_help")C="Viewing%20Search%20Results.4.5.html#1069282";
if(P=="data_basket_help")C="Viewing%20Search%20Results.4.9.html#1070197";
if(P=="download_manager_help")C="Viewing%20Search%20Results.4.12.html#1204360";
if(P=="QA_tool_help")C="NBIA%20admin.6.4.html#1084993";
if(P=="upload_spreadsheet_help")C="NBIA%20admin.6.5.html#1092076";
if(P=="verify_submitted_files_help")C="NBIA%20admin.6.6.html#1110661";
if(P=="submission_report_help")C="NBIA%20admin.6.6.html#1110661";
return C;
}
