function FileData_Pairs(x)
{
x.t("lists","urls");
x.t("url","references");
x.t("products","dicom");
x.t("references","url");
x.t("references","section");
x.t("nbia","ftp");
x.t("cedara","nbia");
x.t("software","products");
x.t("section","lists");
x.t("client","software");
x.t("ftp","client");
x.t("dicom","cedara");
x.t("urls","associated");
x.t("associated","nbia");
}
