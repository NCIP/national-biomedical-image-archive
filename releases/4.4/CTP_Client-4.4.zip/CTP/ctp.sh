
      
      #!/bin/sh
      nohup java -Xmx512m -jar CTP.jar &
      
      