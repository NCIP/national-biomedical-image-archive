
      
      #!/bin/sh
      nohup java -Xmx512m -jar Runner.jar &
      
      